PollPolac - v1.0 --> @escludere


Attenzione: per qualsiasi tipo di problema � disponibile la chat che si pu� trovare
	    sul canale @PollPolac

Soluzioni a problemi comuni:
- "Non riesco a creare sticker": il comando per la creazione degli sticker di PollPolac 
	    usufruisce dei servizi dei bot @QuotLyBot, @Stickerdownloadbot e @toWebmBot , avviarli per essere
	    sicuri che l'ubot funzioni senza problemi.
- "Non riesco a ricavare i dati di un user": come per gli sticker, � necessario avviare
	    il bot @SangMataInfo_bot. Se non dovesse ancora funzionare il problema � del
	    database del bot, non � quindi possibile ottenere le informazioni di un 
	    utente specifico a volte.


